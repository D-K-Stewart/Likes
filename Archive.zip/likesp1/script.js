var count = 0;
var countElement = document.querySelector("#count");

function add1() {
    count++;
    countElement.innerText = count + " like(s)";
    Math.floor
}
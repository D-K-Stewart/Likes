var count = 1;
var countElement = document.querySelector("#count");

function add1() {
    count++;
    countElement.innerText = count + " like(s)";
}

var one = 1;
var oneElement = document.querySelector("#one");

function add2() {
    one++;
    oneElement.innerText = one + " like(s)";
}

var two = 1;
var twoElement = document.querySelector("#two");

function add3() {
    two++;
    twoElement.innerText = two + " like(s)";
}